document.addEventListener("DOMContentLoaded", () => {
  const menuBtn = document.getElementById("menu-btn");
  const systemBtn = document.getElementById("system-btn");
  const onlineBtn = document.getElementById("online-btn");
  const autresBtn = document.getElementById("autres-btn");
  const parametresBtn = document.getElementById("parametres-btn");
  const bureau = document.getElementById("bureau");

  // Gestion des boutons
  menuBtn.addEventListener("click", () => afficherApplications("toutes"));
  systemBtn.addEventListener("click", () => afficherApplications("systeme"));
  onlineBtn.addEventListener("click", () => afficherApplications("online"));
  autresBtn.addEventListener("click", () => afficherApplications("autres"));
  parametresBtn.addEventListener("click", afficherParametres);

  // Affichage des applications
  function afficherApplications(categorie) {
    const apps = Array.from(document.querySelectorAll(".application"));
    apps.forEach((app) => {
      if (categorie === "toutes" || app.dataset.categorie === categorie) {
        app.style.display = "block";
      } else {
        app.style.display = "none";
      }
    });
  }

  // Afficher les paramètres
  function afficherParametres() {
    const modal = document.getElementById("parametres-modal");
    modal.style.display = "block";
  }

  // Fermer le modal au clic en dehors
  document.addEventListener("click", (e) => {
    const modal = document.getElementById("parametres-modal");
    if (e.target === modal) modal.style.display = "none";
  });
});