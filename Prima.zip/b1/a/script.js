document.addEventListener("DOMContentLoaded", () => {
    const desktop = document.getElementById("desktop");
    const contextMenu = document.getElementById("context-menu");
    const addButton = document.getElementById("add-button");
    const modal = document.getElementById("modal");
    const modalTitle = document.getElementById("modal-title");
    const saveAppButton = document.getElementById("save-app");
    const cancelModalButton = document.getElementById("cancel-modal");

    let isContextMenuOpen = false;
    let appToEdit = null; // Variable pour gérer l'application ou le dossier à modifier

    // Afficher le menu contextuel sur clic droit ou maintien prolongé
    desktop.addEventListener("contextmenu", (event) => {
        event.preventDefault();
        contextMenu.style.top = `${event.clientY}px`;
        contextMenu.style.left = `${event.clientX}px`;
        contextMenu.classList.remove("hidden");
        isContextMenuOpen = true;
    });

    // Cacher le menu contextuel
    document.addEventListener("click", () => {
        if (isContextMenuOpen) {
            contextMenu.classList.add("hidden");
            isContextMenuOpen = false;
        }
    });

    // Créer un dossier
    document.getElementById("create-folder").addEventListener("click", () => {
        const folderName = prompt("Nom du dossier :", "Nouveau Dossier");
        if (folderName) {
            const folder = document.createElement("div");
            folder.classList.add("folder");
            folder.innerHTML = `
                <div class="folder-icon">📁</div>
                <p>${folderName}</p>
            `;
            desktop.appendChild(folder);

            // Ajouter la fonctionnalité d'ouverture du dossier
            folder.addEventListener("dblclick", () => openFolder(folderName));
        }
        contextMenu.classList.add("hidden");
        isContextMenuOpen = false;
    });

    // Fonction pour ouvrir un dossier
    function openFolder(folderName) {
        const folderWindow = document.createElement("div");
        folderWindow.classList.add("folder-window");
        folderWindow.innerHTML = `
            <h2>${folderName}</h2>
            <div class="folder-content"></div>
            <button class="close-folder">Fermer</button>
        `;
        document.body.appendChild(folderWindow);

        const folderContent = folderWindow.querySelector(".folder-content");
        folderWindow.querySelector(".close-folder").addEventListener("click", () => {
            document.body.removeChild(folderWindow);
        });

        // Permettre d'ajouter des fichiers ou applications au dossier
        folderContent.addEventListener("dblclick", () => {
            const fileName = prompt("Nom du fichier :", "Nouveau Fichier");
            if (fileName) {
                const file = document.createElement("div");
                file.classList.add("file");
                file.textContent = fileName;
                folderContent.appendChild(file);

                file.addEventListener("dblclick", () => {
                    alert(`Ouverture de "${fileName}"`);
                });
            }
        });
    }

    // Gérer le bouton "+"
    addButton.addEventListener("click", () => {
        appToEdit = null;
        modalTitle.textContent = "Ajouter une application";
        modal.classList.remove("hidden");
    });

    // Fermer la fenêtre modale
    cancelModalButton.addEventListener("click", () => {
        modal.classList.add("hidden");
    });

    // Sauvegarder une nouvelle application
    saveAppButton.addEventListener("click", () => {
        const appName = document.getElementById("app-name").value;
        const appIcon = document.getElementById("app-icon").value || "❓";
        const appFile = document.getElementById("app-file").files[0];

        if (appName && appFile) {
            const reader = new FileReader();
            reader.onload = function (e) {
                const content = e.target.result;

                // Ajouter une nouvelle application
                const newApp = document.createElement("div");
                newApp.classList.add("app-icon");
                newApp.dataset.app = appName.toLowerCase();
                newApp.innerHTML = `
                    ${appIcon}
                    <p>${appName}</p>
                `;

                newApp.addEventListener("dblclick", () => {
                    alert(`Lancement de "${appName}"`);
                });

                desktop.appendChild(newApp);
                alert(`Application "${appName}" ajoutée.`);
                modal.classList.add("hidden");
            };

            reader.readAsText(appFile);
        } else {
            alert("Veuillez remplir tous les champs et importer un fichier HTML.");
        }
    });
});