// Simulation de la base de données des applications installées
const installedApps = [
    { name: "Paramètres", icon: "⚙️", path: "appsys/parametres.html" },
    { name: "Utilisateurs", icon: "👤", path: "appsys/users.html" },
    { name: "Store", icon: "🛒", path: "appsys/store.html" },
    { name: "Calculatrice", icon: "🧮", path: "appsys/calculator.html" },
    { name: "Notes", icon: "📝", path: "appsys/notes.html" },
    { name: "Calendrier", icon: "📅", path: "appsys/calendar.html" }
];

document.addEventListener("DOMContentLoaded", () => {
    const topBar = createTopBar();
    document.body.appendChild(topBar);
});

function createTopBar() {
    const container = document.createElement("div");
    container.id = "top-bar";

    const leftSection = document.createElement("div");
    leftSection.className = "left-section";
    
    const rightSection = document.createElement("div");
    rightSection.className = "right-section";

    const searchContainer = createSearchBar();
    leftSection.appendChild(searchContainer);

    const settingsButton = createButton("⚙️", "Paramètres", () => {
        animateButtonClick(settingsButton);
        window.location.href = "appsys/parametres.html";
    });

    const usersButton = createButton("👤", "Utilisateurs", () => {
        animateButtonClick(usersButton);
        openApp("users");
    });

    const storeButton = createButton("🛒", "Store", () => {
        animateButtonClick(storeButton);
        openApp("store");
    });

    rightSection.appendChild(settingsButton);
    rightSection.appendChild(usersButton);
    rightSection.appendChild(storeButton);

    container.appendChild(leftSection);
    container.appendChild(rightSection);

    return container;
}

function createSearchBar() {
    const container = document.createElement("div");
    container.classList.add("search-container");

    const input = document.createElement("input");
    input.type = "text";
    input.placeholder = "Rechercher...";
    input.id = "search-input";

    const searchResults = document.createElement("div");
    searchResults.id = "search-results";

    input.addEventListener("input", () => {
        const query = input.value.trim().toLowerCase();
        showSearchResults(query, searchResults);
    });

    input.addEventListener("keypress", (e) => {
        if (e.key === "Enter") {
            performSearch();
        }
    });

    input.addEventListener("focus", () => {
        const query = input.value.trim().toLowerCase();
        showSearchResults(query, searchResults);
    });

    document.addEventListener("click", (e) => {
        if (!container.contains(e.target)) {
            searchResults.style.display = "none";
        }
    });

    container.appendChild(input);
    container.appendChild(searchResults);
    return container;
}

function showSearchResults(query, resultsContainer) {
    resultsContainer.innerHTML = "";
    
    if (query.length === 0) {
        resultsContainer.style.display = "none";
        return;
    }

    const matchedApps = installedApps.filter(app => 
        app.name.toLowerCase().includes(query)
    );

    if (matchedApps.length > 0) {
        matchedApps.forEach(app => {
            const resultItem = document.createElement("div");
            resultItem.className = "search-result-item";
            resultItem.innerHTML = `
                <span class="search-result-icon">${app.icon}</span>
                <span>${app.name}</span>
            `;
            resultItem.addEventListener("click", () => {
                window.location.href = app.path;
            });
            resultsContainer.appendChild(resultItem);
        });
        resultsContainer.style.display = "block";
    } else {
        resultsContainer.style.display = "none";
    }
}

function createButton(icon, label, onClickHandler) {
    const button = document.createElement("button");
    button.textContent = icon;
    button.title = label;
    button.addEventListener("click", onClickHandler);
    return button;
}

function animateButtonClick(button) {
    button.style.transform = "scale(0.9)";
    setTimeout(() => {
        button.style.transform = "";
    }, 150);
}

function performSearch() {
    const input = document.getElementById("search-input");
    const query = input.value.trim();
    
    if (!query) {
        input.classList.add("shake");
        setTimeout(() => input.classList.remove("shake"), 500);
        return;
    }

    const matchedApps = installedApps.filter(app => 
        app.name.toLowerCase().includes(query.toLowerCase())
    );

    if (matchedApps.length > 0) {
        window.location.href = matchedApps[0].path;
    } else {
        const platform = "https://www.google.com/search?q=";
        window.open(`${platform}${encodeURIComponent(query)}`, "_blank");
    }
    
    input.classList.add("success-animation");
    setTimeout(() => {
        input.classList.remove("success-animation");
        input.value = "";
    }, 500);
}

function openApp(appName) {
    const appPath = `appsys/${appName}.html`;
    window.location.href = appPath;
}