document.addEventListener("DOMContentLoaded", () => {
    const settingsButton = document.getElementById("settings-button");

    if (settingsButton) {
        settingsButton.addEventListener("click", openSettingsWindow);
    } else {
        console.error("Le bouton Paramètres n'a pas été trouvé dans le DOM.");
    }
});

function openSettingsWindow() {
    const existingWindow = document.getElementById("settings-window");
    if (existingWindow) {
        document.body.removeChild(existingWindow); // Fermer l'ancienne fenêtre si elle existe
    }

    const settingsWindow = document.createElement("div");
    settingsWindow.id = "settings-window";
    settingsWindow.style.position = "fixed";
    settingsWindow.style.top = "50%";
    settingsWindow.style.left = "50%";
    settingsWindow.style.transform = "translate(-50%, -50%)";
    settingsWindow.style.width = "400px";
    settingsWindow.style.background = "rgba(0, 0, 0, 0.9)";
    settingsWindow.style.color = "white";
    settingsWindow.style.borderRadius = "10px";
    settingsWindow.style.boxShadow = "0 4px 10px rgba(0, 0, 0, 0.5)";
    settingsWindow.style.zIndex = "10000";
    settingsWindow.style.padding = "20px";
    settingsWindow.style.display = "flex";
    settingsWindow.style.flexDirection = "column";
    settingsWindow.style.alignItems = "center";
    settingsWindow.style.justifyContent = "center";

    const title = document.createElement("h2");
    title.textContent = "Paramètres";
    title.style.marginBottom = "20px";
    settingsWindow.appendChild(title);

    // Options de paramètres
    const options = [
        { label: "Importer un fond d'écran", app: "fond-ecran" },
        { label: "Changer de thème", app: "themes" },
        { label: "Changer de skin", app: "skins" },
        { label: "Changer de langue", app: "langues" },
        { label: "À propos", app: "a-propos" },
        { label: "Envoyer un message", app: "messages" },
        { label: "Contacter", app: "contacter" }
    ];

    options.forEach(option => {
        const button = document.createElement("button");
        button.textContent = option.label;
        button.style.margin = "10px";
        button.style.padding = "10px 20px";
        button.style.border = "none";
        button.style.borderRadius = "5px";
        button.style.background = "rgba(255, 255, 255, 0.1)";
        button.style.color = "white";
        button.style.cursor = "pointer";

        button.addEventListener("click", () => openApp(option.app));
        settingsWindow.appendChild(button);
    });

    // Bouton pour fermer la fenêtre
    const closeButton = document.createElement("button");
    closeButton.textContent = "Fermer";
    closeButton.style.marginTop = "20px";
    closeButton.style.padding = "10px 20px";
    closeButton.style.border = "none";
    closeButton.style.borderRadius = "5px";
    closeButton.style.background = "#e74c3c";
    closeButton.style.color = "white";

    closeButton.addEventListener("click", () => {
        document.body.removeChild(settingsWindow);
    });

    settingsWindow.appendChild(closeButton);

    document.body.appendChild(settingsWindow);
}

// Fonction pour ouvrir une application depuis le dossier "appsys"
function openApp(appName) {
    const appPath = `appsys/${appName}.html`;

    fetch(appPath)
        .then(response => {
            if (!response.ok) throw new Error(`L'application "${appName}" est introuvable.`);
            return response.text();
        })
        .then(html => {
            const appWindow = document.createElement("div");
            appWindow.classList.add("app-window");
            appWindow.innerHTML = `
                <div class="app-header">
                    <button class="close-btn">X</button>
                </div>
                <div class="app-content">${html}</div>
            `;
            document.body.appendChild(appWindow);

            const closeButton = appWindow.querySelector(".close-btn");
            closeButton.addEventListener("click", () => document.body.removeChild(appWindow));
        })
        .catch(error => {
            alert(error.message);
        });
}