document.addEventListener("DOMContentLoaded", () => {
    const topBar = createTopBar();
    document.body.appendChild(topBar);
});

// Création de la barre de tâches haut
function createTopBar() {
    const container = document.createElement("div");
    container.id = "top-bar";

    // Barre de recherche
    const searchContainer = createSearchBar();

    // Boutons supplémentaires
    const settingsButton = createButton("⚙️", "Paramètres", () => {
        window.location.href = "appsys/parametres.html";
    });

    const usersButton = createButton("👤", "Utilisateurs", openApp.bind(null, "users"));
    const storeButton = createButton("🛒", "Store", openApp.bind(null, "store"));

    container.appendChild(searchContainer);
    container.appendChild(settingsButton);
    container.appendChild(usersButton);
    container.appendChild(storeButton);

    return container;
}

// Création de la barre de recherche
function createSearchBar() {
    const container = document.createElement("div");
    container.classList.add("search-container");

    const input = document.createElement("input");
    input.type = "text";
    input.placeholder = "Rechercher...";
    input.id = "search-input";

    const searchButton = document.createElement("button");
    searchButton.textContent = "🔍";
    searchButton.addEventListener("click", performSearch);

    container.appendChild(input);
    container.appendChild(searchButton);

    return container;
}

// Création de boutons avec gestion des clics
function createButton(icon, label, onClickHandler) {
    const button = document.createElement("button");
    button.textContent = `${icon} ${label}`;
    button.addEventListener("click", onClickHandler);
    return button;
}

// Gestion de la recherche
function performSearch() {
    const query = document.getElementById("search-input").value;
    if (!query) return;

    const platform = "https://www.google.com/search?q=";
    window.open(`${platform}${encodeURIComponent(query)}`, "_blank");
}

// Fonction pour ouvrir une application depuis le dossier "appsys"
function openApp(appName) {
    const appPath = `appsys/${appName}.html`;
    window.location.href = appPath;
}