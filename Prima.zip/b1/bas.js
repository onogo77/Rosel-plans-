// Script pour une barre inférieure dynamique et interactive

document.addEventListener('DOMContentLoaded', () => {
  const appContainer = createAppContainer();
  document.body.appendChild(appContainer);

  const bottomBar = createBottomBar([
    { id: 1, label: "App1", icon: "🛖", path: "app/app1.html" },
    { id: 2, label: "App2", icon: "📚", path: "app/app2.html" },
    { id: 3, label: "App3", icon: "📊", path: "app/app3.html" },
    { id: 4, label: "App4", icon: "🎨", path: "app/app4.html" },
    { id: 5, label: "App5", icon: "🎮", path: "app/app5.html" },
  ]);

  document.body.appendChild(bottomBar);
});

// Création de la barre inférieure
function createBottomBar(apps) {
  const bar = document.createElement('div');
  bar.id = 'bottom-bar';
  bar.style.position = 'fixed';
  bar.style.bottom = '10px';
  bar.style.left = '50%';
  bar.style.transform = 'translateX(-50%)';
  bar.style.display = 'flex';
  bar.style.justifyContent = 'center';
  bar.style.alignItems = 'center';
  bar.style.gap = '15px';
  bar.style.padding = '10px 20px';
  bar.style.borderRadius = '30px';
  bar.style.background = 'rgba(0, 0, 0, 0.6)';
  bar.style.boxShadow = '0px 4px 10px rgba(0, 0, 0, 0.3)';
  bar.style.backdropFilter = 'blur(10px)';
  bar.style.zIndex = '9999';

  apps.forEach(app => {
    const appIcon = createAppIcon(app);
    bar.appendChild(appIcon);
  });

  return bar;
}

// Création des icônes pour les applications
function createAppIcon(app) {
  const icon = document.createElement('div');
  icon.className = 'app-icon';
  icon.textContent = app.icon;
  icon.title = app.label;

  icon.style.width = '50px';
  icon.style.height = '50px';
  icon.style.display = 'flex';
  icon.style.justifyContent = 'center';
  icon.style.alignItems = 'center';
  icon.style.fontSize = '35px';
  icon.style.color = 'white';
  icon.style.borderRadius = '50%';
  icon.style.background = 'rgba(255, 255, 255, 0.1)';
  icon.style.cursor = 'pointer';
  icon.style.transition = 'all 0.3s ease';

  icon.addEventListener('mouseover', () => {
    icon.style.background = 'rgba(255, 255, 255, 0.3)';
    icon.style.transform = 'scale(1.1)';
  });

  icon.addEventListener('mouseout', () => {
    icon.style.background = 'rgba(255, 255, 255, 0.1)';
    icon.style.transform = 'scale(1)';
  });

  icon.addEventListener('click', () => openApp(app.path));

  // Drag-and-Drop (optionnel)
  icon.draggable = true;
  icon.addEventListener('dragstart', handleDragStart);
  icon.addEventListener('dragover', handleDragOver);
  icon.addEventListener('drop', handleDrop);

  return icon;
}

// Conteneur pour afficher les applications
function createAppContainer() {
  const container = document.createElement('div');
  container.id = 'app-container';
  container.style.position = 'fixed';
  container.style.top = '0';
  container.style.left = '0';
  container.style.width = '100vw';
  container.style.height = '100vh';
  container.style.background = 'rgba(0, 0, 0, 0.8)';
  container.style.display = 'none';
  container.style.justifyContent = 'center';
  container.style.alignItems = 'center';
  container.style.zIndex = '999';

  const iframe = document.createElement('iframe');
  iframe.id = 'app-iframe';
  iframe.style.width = '80%';
  iframe.style.height = '80%';
  iframe.style.border = 'none';
  iframe.style.borderRadius = '10px';
  container.appendChild(iframe);

  const closeButton = document.createElement('button');
  closeButton.textContent = 'Fermer';
  closeButton.style.position = 'absolute';
  closeButton.style.top = '20px';
  closeButton.style.right = '20px';
  closeButton.style.padding = '10px';
  closeButton.style.background = 'red';
  closeButton.style.color = 'white';
  closeButton.style.border = 'none';
  closeButton.style.borderRadius = '5px';
  closeButton.style.cursor = 'pointer';

  closeButton.addEventListener('click', () => {
    container.style.display = 'none';
    iframe.src = '';
  });

  container.appendChild(closeButton);

  return container;
}

// Gestion du Drag-and-Drop
function handleDragStart(event) {
  event.dataTransfer.setData('text/plain', event.target.outerHTML);
  event.target.style.opacity = '0.5';
}

function handleDragOver(event) {
  event.preventDefault();
}

function handleDrop(event) {
  event.preventDefault();
  const droppedHTML = event.dataTransfer.getData('text/plain');
  const droppedElement = document.createElement('div');
  droppedElement.innerHTML = droppedHTML;
  event.target.parentElement.appendChild(droppedElement.firstChild);
}

// Ouverture d'une application dans l'iframe
function openApp(path) {
  const iframe = document.getElementById('app-iframe');
  iframe.src = path;
  document.getElementById('app-container').style.display = 'flex';
}