document.addEventListener("DOMContentLoaded", () => {
    const cards = document.querySelectorAll(".settings-card");
    const detailsContainer = document.getElementById("details-container");
    const detailsTitle = document.getElementById("details-title");
    const detailsDescription = document.getElementById("details-description");
    const detailsAction = document.getElementById("details-action");

    cards.forEach(card => {
        card.addEventListener("click", () => {
            const param = card.dataset.param;
            showDetails(param);
        });
    });

    function showDetails(param) {
        detailsContainer.classList.remove("hidden");

        switch (param) {
            case "fond-ecran":
                detailsTitle.textContent = "Importer un fond d'écran";
                detailsDescription.textContent = "Choisissez une image pour définir comme fond d'écran.";
                detailsAction.innerHTML = '<input type="file" id="upload-wallpaper" accept="image/*">';
                break;
            case "themes":
                detailsTitle.textContent = "Changer de thème";
                detailsDescription.textContent = "Sélectionnez un thème pour personnaliser l'apparence.";
                detailsAction.innerHTML = '<button onclick="alert(\'Thème changé !\')">Changer de thème</button>';
                break;
            case "skins":
                detailsTitle.textContent = "Changer de skin";
                detailsDescription.textContent = "Personnalisez le style visuel du système.";
                detailsAction.innerHTML = '<button onclick="alert(\'Skin appliqué !\')">Appliquer un skin</button>';
                break;
            case "langues":
                detailsTitle.textContent = "Changer de langue";
                detailsDescription.textContent = "Sélectionnez une langue pour le système.";
                detailsAction.innerHTML = `
                    <select>
                        <option value="fr">Français</option>
                        <option value="en">English</option>
                        <option value="es">Español</option>
                    </select>`;
                break;
            case "a-propos":
                detailsTitle.textContent = "À propos";
                detailsDescription.textContent = "Informations sur le système et l'équipe.";
                detailsAction.innerHTML = "<p>Version 1.0.0</p>";
                break;
            case "messages":
                detailsTitle.textContent = "Envoyer un message";
                detailsDescription.textContent = "Envoyez-nous vos suggestions ou signalez un problème.";
                detailsAction.innerHTML = '<textarea placeholder="Votre message ici"></textarea><button onclick="alert(\'Message envoyé !\')">Envoyer</button>';
                break;
            case "contacter":
                detailsTitle.textContent = "Contacter";
                detailsDescription.textContent = "Obtenez de l'aide ou contactez l'équipe de support.";
                detailsAction.innerHTML = "<p>Email : support@example.com</p>";
                break;
            default:
                detailsTitle.textContent = "Option inconnue";
                detailsDescription.textContent = "Cette option n'est pas encore disponible.";
                detailsAction.innerHTML = "";
        }
    }

    // Fonction pour fermer les détails
    window.closeDetails = function () {
        detailsContainer.classList.add("hidden");
        detailsTitle.textContent = "";
        detailsDescription.textContent = "";
        detailsAction.innerHTML = "";
    };
});