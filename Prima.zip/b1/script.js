document.addEventListener("DOMContentLoaded", () => {
    const desktop = document.getElementById("desktop");
    const addButton = document.getElementById("add-button");
    const modal = document.getElementById("modal");
    const modalTitle = document.getElementById("modal-title");
    const saveAppButton = document.getElementById("save-app");
    const cancelModalButton = document.getElementById("cancel-modal");







    // Gérer l'ouverture des applications par défaut
    const appIcons = document.querySelectorAll(".app-icon");
    appIcons.forEach((icon) => {
        icon.addEventListener("click", () => {
            const appPath = icon.dataset.app;
            openApplication(appPath);
        });
    });

    // Gérer le bouton "+" pour ajouter une application
    addButton.addEventListener("click", () => {
        modalTitle.textContent = "Ajouter une application";
        modal.classList.remove("hidden");
    });

    // Fermer la fenêtre modale
    cancelModalButton.addEventListener("click", () => {
        modal.classList.add("hidden");
    });

    // Sauvegarder une nouvelle application
    saveAppButton.addEventListener("click", () => {
        const appName = document.getElementById("app-name").value.trim();
        const appIcon = document.getElementById("app-icon").value || "❓";
        const appFile = document.getElementById("app-file").files[0];

        if (appName && appFile) {
            const reader = new FileReader();
            reader.onload = function (e) {
                const content = e.target.result;

                // Simuler la copie du fichier dans le dossier apps-user
                const appPath = `apps-user/${appName.toLowerCase()}.html`;
                saveFile(appPath, content);

                // Ajouter l'application au bureau
                const newApp = document.createElement("div");
                newApp.classList.add("app-icon");
                newApp.dataset.app = appPath;
                newApp.innerHTML = `
                    ${appIcon}
                    <p>${appName}</p>
                `;

                newApp.addEventListener("click", () => {
                    openApplication(appPath);
                });

                desktop.appendChild(newApp);
                alert(`Application "${appName}" ajoutée avec succès.`);
                modal.classList.add("hidden");
            };

            reader.readAsText(appFile);
        } else {
            alert("Veuillez remplir tous les champs et sélectionner un fichier HTML.");
        }
    });

    // Ouvrir une application
    function openApplication(appPath) {
        fetch(appPath)
            .then((response) => {
                if (!response.ok) {
                    throw new Error(`Application non trouvée dans ${appPath}`);
                }
                return response.text();
            })
            .then((html) => {
                const appWindow = document.createElement("div");
                appWindow.classList.add("app-window");
                appWindow.innerHTML = `
                    <div class="app-header">
                        <button class="close-btn">X</button>
                    </div>
                    <div class="app-content">${html}</div>
                `;
                document.body.appendChild(appWindow);

                // Gérer la fermeture de l'application
                const closeButton = appWindow.querySelector(".close-btn");
                closeButton.addEventListener("click", () => {
                    document.body.removeChild(appWindow);
                });
            })
            .catch((error) => {
                alert(error.message);
            });
    }

    // Simuler la sauvegarde d'un fichier dans le dossier apps-user
    function saveFile(filePath, content) {
        console.log(`Fichier sauvegardé dans : ${filePath}`);
        // Note : Cette fonctionnalité nécessite un backend pour réellement sauvegarder des fichiers.
    }
});



document.addEventListener("DOMContentLoaded", () => {
    const addButton = document.getElementById("add-button");
    const modal = document.getElementById("modal");
    const cancelModalButton = document.getElementById("cancel-modal");

    // Afficher la fenêtre modale lorsqu'on clique sur "+"
    addButton.addEventListener("click", () => {
        modal.classList.remove("hidden"); // Afficher la modale
    });

    // Fermer la fenêtre modale
    cancelModalButton.addEventListener("click", () => {
        modal.classList.add("hidden"); // Masquer la modale
    });
});





document.addEventListener("DOMContentLoaded", () => {
    const addButton = document.getElementById("add-button");
    const modal = document.getElementById("modal");
    const saveAppButton = document.getElementById("save-app");
    const cancelModalButton = document.getElementById("cancel-modal");
    const appNameInput = document.getElementById("app-name");
    const appIconInput = document.getElementById("app-icon");

    // Afficher la modale lorsque l'utilisateur clique sur le bouton "+"
    addButton.addEventListener("click", () => {
        modal.style.display = "flex";
    });

    // Sauvegarder une nouvelle application
    saveAppButton.addEventListener("click", () => {
        const name = appNameInput.value.trim();
        const icon = appIconInput.value.trim();

        if (name && icon) {
            // Ici, on pourrait ajouter l'application à l'interface
            alert(`Application ajoutée: ${name} avec l'icône ${icon}`);
            appNameInput.value = "";
            appIconInput.value = "";
            modal.style.display = "none"; // Fermer la modale
        } else {
            alert("Veuillez remplir tous les champs !");
        }
    });

    // Annuler et fermer la modale
    cancelModalButton.addEventListener("click", () => {
        appNameInput.value = "";
        appIconInput.value = "";
        modal.style.display = "none"; // Fermer la modale
    });
});





window.onload = function () {
  const savedWallpaper = localStorage.getItem('wallpaper');
  const savedGradient = localStorage.getItem('gradient');
  const savedThemeGradient = localStorage.getItem('themeGradient');
  const savedSkin = localStorage.getItem('currentSkin');
  if (savedWallpaper) {
    document.body.style.backgroundImage = `url(${savedWallpaper})`;
    document.body.style.backgroundSize = 'cover';
    document.body.style.backgroundPosition = 'center';
  } else if (savedGradient) {
    document.body.style.background = savedGradient;
  } else if (savedThemeGradient) {
    document.body.style.background = savedThemeGradient;
  }
  if (savedSkin) {
    applySkin(savedSkin);
  }
}