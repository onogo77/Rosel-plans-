// Barre de recherche puissante avec suggestions en temps réel
document.addEventListener("DOMContentLoaded", () => {
  const searchBar = createSearchBar();
  document.body.appendChild(searchBar);
});

// Création de la barre de recherche
function createSearchBar() {
  const container = document.createElement("div");
  container.id = "search-bar";
  container.style.position = "fixed";
  container.style.top = "10px";
  container.style.left = "50%";
  container.style.transform = "translateX(-50%)";
  container.style.display = "flex";
  container.style.alignItems = "center";
  container.style.gap = "10px";
  container.style.padding = "10px 20px";
  container.style.background = "rgba(0, 0, 0, 0.6)";
  container.style.borderRadius = "25px";
  container.style.boxShadow = "0px 4px 10px rgba(0, 0, 0, 0.3)";
  container.style.backdropFilter = "blur(10px)";
  container.style.zIndex = "9999";

  const input = document.createElement("input");
  input.type = "text";
  input.placeholder = "Rechercher...";
  input.id = "search-input";
  input.style.padding = "10px";
  input.style.border = "none";
  input.style.outline = "none";
  input.style.borderRadius = "20px";
  input.style.background = "rgba(255, 255, 255, 0.1)";
  input.style.color = "white";
  input.style.fontSize = "16px";
  input.style.transition = "all 0.3s ease";
  input.style.flex = "1";

  input.addEventListener("input", handleInput);

  const searchButton = document.createElement("button");
  searchButton.textContent = "🔍";
  searchButton.style.border = "none";
  searchButton.style.outline = "none";
  searchButton.style.background = "rgba(255, 255, 255, 0.2)";
  searchButton.style.color = "white";
  searchButton.style.borderRadius = "50%";
  searchButton.style.width = "40px";
  searchButton.style.height = "40px";
  searchButton.style.display = "flex";
  searchButton.style.justifyContent = "center";
  searchButton.style.alignItems = "center";
  searchButton.style.cursor = "pointer";
  searchButton.style.transition = "all 0.3s ease";

  searchButton.addEventListener("click", performSearch);

  const suggestions = document.createElement("ul");
  suggestions.id = "search-suggestions";
  suggestions.style.position = "absolute";
  suggestions.style.top = "50px";
  suggestions.style.left = "50%";
  suggestions.style.transform = "translateX(-50%)";
  suggestions.style.width = "300px";
  suggestions.style.background = "rgba(0, 0, 0, 0.8)";
  suggestions.style.borderRadius = "10px";
  suggestions.style.padding = "10px";
  suggestions.style.listStyle = "none";
  suggestions.style.margin = "0";
  suggestions.style.boxShadow = "0px 4px 10px rgba(0, 0, 0, 0.3)";
  suggestions.style.display = "none";
  suggestions.style.zIndex = "10000";

  container.appendChild(input);
  container.appendChild(searchButton);
  container.appendChild(suggestions);

  return container;
}

// Gestion de la saisie et des suggestions
async function handleInput(event) {
  const query = event.target.value.toLowerCase();
  const suggestions = document.getElementById("search-suggestions");

  if (query.length === 0) {
    suggestions.style.display = "none";
    return;
  }

  const data = await fetchSuggestions(query);
  suggestions.innerHTML = "";

  if (data.length > 0) {
    data.forEach(item => {
      const li = document.createElement("li");
      li.textContent = item;
      li.style.padding = "8px";
      li.style.cursor = "pointer";
      li.style.color = "white";

      li.addEventListener("click", () => {
        document.getElementById("search-input").value = item;
        suggestions.style.display = "none";
      });

      li.addEventListener("mouseover", () => {
        li.style.background = "rgba(255, 255, 255, 0.2)";
      });

      li.addEventListener("mouseout", () => {
        li.style.background = "transparent";
      });

      suggestions.appendChild(li);
    });
    suggestions.style.display = "block";
  } else {
    suggestions.style.display = "none";
  }
}

// Rechercher dans un fichier JSON
async function fetchSuggestions(query) {
  const response = await fetch("data/search-data.json");
  const data = await response.json();
  return data.filter(item => item.toLowerCase().includes(query));
}

// Effectuer une recherche (ouverture d'une plateforme)
function performSearch() {
  const query = document.getElementById("search-input").value;
  if (!query) return;

  const platform = "https://www.google.com/search?q="; // Exemple : Google
  window.open(`${platform}${encodeURIComponent(query)}`, "_blank");
}