document.addEventListener("DOMContentLoaded", () => {
    const addButton = document.getElementById("add-button");
    const modal = document.getElementById("modal");
    const saveAppButton = document.getElementById("save-app");
    const cancelModalButton = document.getElementById("cancel-modal");
    const appNameInput = document.getElementById("app-name");
    const appIconInput = document.getElementById("app-icon");

    // Afficher la modale lorsque l'utilisateur clique sur le bouton "+"
    addButton.addEventListener("click", () => {
        modal.style.display = "flex";
    });

    // Sauvegarder une nouvelle application
    saveAppButton.addEventListener("click", () => {
        const name = appNameInput.value.trim();
        const icon = appIconInput.value.trim();

        if (name && icon) {
            // Ici, on pourrait ajouter l'application à l'interface
            alert(`Application ajoutée: ${name} avec l'icône ${icon}`);
            appNameInput.value = "";
            appIconInput.value = "";
            modal.style.display = "none"; // Fermer la modale
        } else {
            alert("Veuillez remplir tous les champs !");
        }
    });

    // Annuler et fermer la modale
    cancelModalButton.addEventListener("click", () => {
        appNameInput.value = "";
        appIconInput.value = "";
        modal.style.display = "none"; // Fermer la modale
    });
});


