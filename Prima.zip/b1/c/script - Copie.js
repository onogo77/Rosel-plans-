document.addEventListener("DOMContentLoaded", () => {
    const desktop = document.getElementById("desktop");
    const addButton = document.getElementById("add-button");
    const modal = document.getElementById("modal");
    const saveAppButton = document.getElementById("save-app");
    const cancelModalButton = document.getElementById("cancel-modal");
    const appNameInput = document.getElementById("app-name");
    const appIconInput = document.getElementById("app-icon");
    const maxAppsPerPage = 16; // 4 colonnes * 4 lignes
    let currentPageIndex = 0;
    let pages = [];
    
    // Créer une nouvelle page si nécessaire
    function createPage() {
        const page = document.createElement("div");
        page.className = "page";
        desktop.appendChild(page);
        pages.push(page);
        return page;
    }

    // Créer la première page
    createPage();

    // Fonction pour afficher ou masquer les flèches de navigation
    function updateArrows() {
        leftArrow.classList.toggle("hidden", currentPageIndex === 0);
        rightArrow.classList.toggle("hidden", currentPageIndex === pages.length - 1);
    }

    // Ajouter une application à la page actuelle
    function addApp(name, icon) {
        const currentPage = pages[currentPageIndex];
        
        // Si la page est pleine, créer une nouvelle page
        if (currentPage.children.length >= maxAppsPerPage) {
            createPage();
            navigateToPage(currentPageIndex + 1);
        }

        // Créer l'élément de l'application
        const app = document.createElement("div");
        app.className = "app-icon";
        app.innerHTML = `
            ${icon || "📦"}
            <p>${name || "App"}</p>
        `;
        currentPage.appendChild(app);
    }

    // Fonction pour naviguer vers une page spécifique
    function navigateToPage(index) {
        currentPageIndex = index;
        desktop.style.transform = `translateX(-${index * 100}%)`;
        updateArrows();
    }

    // Ajout du bouton "+"
    addButton.addEventListener("click", () => {
        modal.style.display = "flex";  // Ouvrir la fenêtre modale
    });

    // Sauvegarder une nouvelle application
    saveAppButton.addEventListener("click", () => {
        const name = appNameInput.value.trim();
        const icon = appIconInput.value.trim();
        
        if (name && icon) {
            addApp(name, icon);
            appNameInput.value = "";  // Vider les champs
            appIconInput.value = "";
            modal.style.display = "none";  // Fermer la modale
        } else {
            alert("Veuillez remplir tous les champs !");
        }
    });

    // Annuler la modale
    cancelModalButton.addEventListener("click", () => {
        appNameInput.value = "";
        appIconInput.value = "";
        modal.style.display = "none";
    });

    // Initialisation des flèches de navigation
    const leftArrow = document.createElement("div");
    const rightArrow = document.createElement("div");
    leftArrow.className = "arrow left hidden";
    leftArrow.textContent = "‹";
    rightArrow.className = "arrow right hidden";
    rightArrow.textContent = "›";
    document.body.appendChild(leftArrow);
    document.body.appendChild(rightArrow);

    // Navigation avec les flèches
    leftArrow.addEventListener("click", () => {
        if (currentPageIndex > 0) navigateToPage(currentPageIndex - 1);
    });

    rightArrow.addEventListener("click", () => {
        if (currentPageIndex < pages.length - 1) navigateToPage(currentPageIndex + 1);
    });

    // Mise à jour des flèches lors du redimensionnement de la fenêtre
    window.addEventListener("resize", () => {
        navigateToPage(currentPageIndex); // Réajustement du défilement
    });

    // Ajouter quelques applications par défaut
    const defaultApps = [
        { name: "Musique", icon: "🎵" },
        { name: "Boissons", icon: "🥤" },
        { name: "Clavier", icon: "⌨️" },
        { name: "Jeu", icon: "🍄" },
        { name: "Photos", icon: "😚" },
        { name: "Émotions", icon: "😁" },
        { name: "Paysage", icon: "🌄" },
        { name: "Recettes", icon: "🫓" },
        { name: "Travail", icon: "👷" }
    ];

    defaultApps.forEach(app => addApp(app.name, app.icon));  // Ajouter les applications par défaut
});