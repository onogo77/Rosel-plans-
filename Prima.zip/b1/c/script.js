// Récupération des éléments DOM
const addButton = document.getElementById('add-button');
const modal = document.getElementById('modal');
const cancelModalButton = document.getElementById('cancel-modal');
const saveAppButton = document.getElementById('save-app');
const appNameInput = document.getElementById('app-name');
const appIconInput = document.getElementById('app-icon');
const appFileInput = document.getElementById('app-file');

// Afficher la fenêtre modale lorsque le bouton "+" est cliqué
addButton.addEventListener('click', () => {
    modal.style.display = 'flex';
});

// Fermer la fenêtre modale lorsque "Annuler" est cliqué
cancelModalButton.addEventListener('click', () => {
    modal.style.display = 'none';
    appNameInput.value = '';
    appIconInput.value = '';
    appFileInput.value = '';
});

// Sauvegarder l'application et copier le fichier dans le dossier virtuel
saveAppButton.addEventListener('click', () => {
    const appName = appNameInput.value.trim();
    const appIcon = appIconInput.value.trim();
    const appFile = appFileInput.files[0];

    if (!appName || !appIcon || !appFile) {
        alert("Veuillez remplir tous les champs.");
        return;
    }

    // Lire le contenu du fichier HTML sélectionné
    const reader = new FileReader();
    reader.onload = function(event) {
        const fileContent = event.target.result;

        // Créer un nom de fichier pour l'application
        const fileName = appName + '.html';

        // Définir le dossier virtuel "apps-user" (ici on simule)
        const appsUserDirectory = 'apps-user/';
        
        // Simulation de l'enregistrement du fichier dans le dossier virtuel
        saveFileToVirtualDirectory(appsUserDirectory, fileName, fileContent);

        // Fermer la modale après l'installation
        modal.style.display = 'none';
        alert(`${appName} a été installé avec succès.`);
    };

    reader.readAsText(appFile);
});

// Fonction pour simuler l'enregistrement du fichier dans un dossier virtuel
function saveFileToVirtualDirectory(directory, fileName, content) {
    console.log(`Fichier "${fileName}" sauvegardé dans le dossier virtuel "${directory}"`);
    // Vous devez ici utiliser un mécanisme de stockage virtuel comme IndexedDB, LocalStorage ou autres
    // qui permettent de garder des fichiers dans un environnement web sans interférer avec le système de fichiers local.
}
